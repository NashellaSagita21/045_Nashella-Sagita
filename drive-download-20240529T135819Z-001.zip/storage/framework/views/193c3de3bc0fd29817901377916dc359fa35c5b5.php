

<?php $__env->startSection('title', 'Home'); ?>
    <h4>
        Selamat Datang 
    </h4>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\praktikum framework\perpus\resources\views/home.blade.php ENDPATH**/ ?>